﻿using System;
class Semana8_Actividad2 
{
    public static void Main(string[] args) 
    {
        int numero; 
        bool entradaValida = false;  
        do
        {
            Console.Write("Ingrese un número entero válido: "); 
            string entrada = Console.ReadLine();
            
            if(int.TryParse(entrada, out numero))
            {
                int factorial = CalcularFactoria(numero);
                Console.WriteLine("El factorial de es: " + factorial);
                entradaValida = true;
            }
            else
            {
                Console.WriteLine("Dato no válido. ");
                Console.WriteLine("Intente de nuevo. ");
            }
        } 
        while(!entradaValida);
    
    }
    public static int CalcularFactoria(int numero)
    {
        if (numero == 0)
        { 
            return 1;
        }     
        else
        { 
            int factorial = 1; 
            for (int i = 1; i <= numero; i++)
            {
                factorial *= i;
            }    
            return factorial; 
        }
    }            
}

