﻿using System;

class Program
{
    static void Main()
    {
        // Solicitar y guardar 
        int[] numeros = new int[8];
        for (int i = 0; i < 8; i++)
        {
            Console.Write("Ingrese el número " + (i + 1) + ": ");
            numeros[i] = Convert.ToInt16(Console.ReadLine());
        }
        // Mostrar números
        Console.WriteLine("\nNúmeros ingresados:");
        foreach (int num in numeros)
        {
            Console.WriteLine($"{num} ");
        }
        // Suma
        int suma = 0;
        foreach (int num in numeros)
        {
            suma += num;
        }
        Console.WriteLine("Suma total:" + suma);
        // Promedio
        int promedio = suma / 8;
        Console.WriteLine("Promedio:" + promedio.ToString("0"));
        Console.WriteLine("Precina cualquier tecla para salir ... "); 
        Console.ReadKey();
    }
}
