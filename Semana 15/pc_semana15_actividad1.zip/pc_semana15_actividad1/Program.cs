﻿using System;
class Estudiante
{
    public string Nombre { get; set; }
    public int Edad { get; set; }
    public string Carrera { get; set; }
    public string Carnet { get; set; }
    public double NotaAdmision { get; set; }
    public void MostrarResumen()
    {
        Console.WriteLine("Datos del estudiante. ");
        Console.WriteLine($"Nombre: {Nombre}");
        Console.WriteLine($"Edad: {Edad}");
        Console.WriteLine($"Carrera: {Carrera}");
        Console.WriteLine($"Carnet: {Carnet}");
        Console.WriteLine($"Nota de Admisión: {NotaAdmision}");
    }
    public bool MatricularAprobada()
    {
        return NotaAdmision >= 75;
    }
    public bool CarnetValido()
    {
        return Carnet.EndsWith("2025");
    }
}
class Program
{
    static void Main(string[] args)
    {
        Estudiante estudiante = new Estudiante();
        Console.Write("Ingrese su nombre: ");
        estudiante.Nombre = Console.ReadLine();
        Console.Write("Ingrese su edad: ");
        estudiante.Edad = int.Parse(Console.ReadLine());
        Console.Write("Ingrese su carrera: ");
        estudiante.Carrera = Console.ReadLine();
        Console.Write("Ingrese su carnet de estudiante: ");
        estudiante.Carnet = Console.ReadLine();
        Console.Write("Ingrese la nota de admisión obtenida: ");
        estudiante.NotaAdmision = double.Parse(Console.ReadLine());
        estudiante.MostrarResumen();
        if (estudiante.MatricularAprobada())
        {
            Console.WriteLine("El estudiante si puede matricularse.");
        }
        else
        {
            Console.WriteLine("El estudiante no se puede matricularse.");
        }
        if (estudiante.CarnetValido())
        {
            Console.WriteLine("Carnet valido.");
        }
        else
        {
            Console.WriteLine("Carnet no valido. ");
        }
        Console.WriteLine("Presione cualquier tecla para salir...");
        Console.ReadKey();
    }
}