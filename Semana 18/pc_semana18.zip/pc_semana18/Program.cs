﻿using System;
// Nombre: Pablo Fernando Escobar Armas. 
// Carnet: 2000125. 
class Programa
{
    static void Main()
    {
        DatosEstudiantes gestor = new DatosEstudiantes();
        gestor.IngresarDatos();
        MenuOpciones menu = new MenuOpciones(gestor);
        menu.Mostrar();
    }
}
class Estudiantes
{
    public string Nombre { get; set; }
    public int Nota { get; set; }
    public Estudiantes(string nombre, int nota)
    {
        Nombre = nombre;
        Nota = nota;
    }
    public bool EstaAprobado()
    {
        return Nota >= 60;
    }
}
class DatosEstudiantes
{
    private Estudiantes[] estudiantes = new Estudiantes[10];
    public void IngresarDatos()
    {
        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Ingrese el nombre del estudiante No. {i + 1}: ");
            string nombre = Console.ReadLine();
            int nota;
            while (true)
            {
                Console.Write($"Ingrese la nota del estudiante No. {i + 1} (0 a 100): ");
                string notaEstudiante = Console.ReadLine();
                bool estudianteNumero = int.TryParse(notaEstudiante, out nota);
                if (estudianteNumero && nota >= 0 && nota <= 100)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Ingrese una nota válida entre 0 y 100.");
                }
            }
            estudiantes[i] = new Estudiantes(nombre, nota);
        }
    }
    public void EstudiantesAprobados()
    {
        Console.WriteLine("Los estudiantes que aprobaron con notas ente 60 a 100: ");
        foreach (var estudiante in estudiantes)
        {
            if (estudiante.EstaAprobado())
            {
                Console.WriteLine($"{estudiante.Nombre} - {estudiante.Nota}");
            }
        }
    }
    public void EstudiantesReprobados()
    {
        Console.WriteLine("Los estudiantes que no aprobaron: ");
        foreach (var estudiante in estudiantes)
        {
            if (!estudiante.EstaAprobado())
            {
                Console.WriteLine($"{estudiante.Nombre} - {estudiante.Nota}");
            }
        }
    }
    public void Promedio()
    {
        int sumaPromedio = 0;
        foreach (var estudiante in estudiantes)
        {
            sumaPromedio += estudiante.Nota;
        }
        double promedio = sumaPromedio / (double)estudiantes.Length;
        Console.WriteLine($"Promedio de notas de la clase: {promedio:F2}");
    }
}
class MenuOpciones
{
    private DatosEstudiantes gestor;
    public MenuOpciones(DatosEstudiantes gestor)
    {
        this.gestor = gestor;
    }
    public void Mostrar()
    {
        int opcion;
        do
        {
            Console.WriteLine("1. Estudiantes aprobados. ");
            Console.WriteLine("2. Estudiantes reprobados. ");
            Console.WriteLine("3. Promedio de la clase. ");
            Console.WriteLine("4. Salir. ");
            Console.Write("Seleccione una opción: ");
            bool opccionMenu = int.TryParse(Console.ReadLine(), out opcion);
            if (!opccionMenu)
            {
                Console.WriteLine("Opción no válida. Intente de nuevo.");
                continue;
            }
            switch (opcion)
            {
                case 1:
                    gestor.EstudiantesAprobados();
                    break;
                case 2:
                    gestor.EstudiantesAprobados();
                    break;
                case 3:
                    gestor.Promedio();
                    break;
                case 4:
                    Console.WriteLine("Saliendo del programa...");
                    break;
                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 4);
    }
}
