﻿using System; 
namespace semana5_a3_PabloEscobar
{
    class semana5_a3 
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrse un numero: ");
            int N1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese otro numero: ");
            int N2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese otro numero: ");
            int N3 = int.Parse(Console.ReadLine()); 
            if (N1 > N2)
            {
                if (N1>N3)
                {
                    Console.WriteLine("El numero mayor es: "+N1);
                    if (N1>N3)
                {
                    Console.WriteLine("El numero mayor es: "+N1);
                    if(N2>N3)
                    {
                        Console.WriteLine("El numero menor es: "+N3);
                    }
                    else
                    {
                        Console.WriteLine("El numero menor es: "+N2);
                    }
                }
                else
                {
                    Console.WriteLine("El numero mayor es: "+N3);
                    if(N1>N2)
                    {
                        Console.WriteLine("El numero menor es: "+N2);
                    }
                    else
                    {
                        Console.WriteLine("El numero menor es: "+N1);
                    }
                else
                {
                    Console.WriteLine("El numero mayor es: "+N3);
                    if(N1>N2)
                    {
                        Console.WriteLine("El numero menor es: "+N2);
                    }
                    else
                    {
                        Console.WriteLine("El numero menor es: "+N1);
                    }
                }
                }
            else
            {
                if (N2>N3)
                {
                    Console.WriteLine("El numero mayor es: "+N2);
                    if(N1>N3)
                    {
                        Console.WriteLine("El numero menor es: "+N3);
                    }
                    else
                    {
                        Console.WriteLine("El numero menor es: "+N1);
                    }
                }
                else
                {
                    Console.WriteLine("El numero mayor es: "+N3);
                    if(N1>N2)
                    {
                        Console.WriteLine("El numero menor es: "+N2);
                    }
                    else
                    {
                        Console.WriteLine("El numero menor es: "+N1);
                    }
                }
            }
        }  
    }
} 